package org.example;

public class Odkurzacz extends Urzadzenie{
    private boolean stanOdkurzacza = false;
    public void on(){
        if (stanOdkurzacza == false){
            stanOdkurzacza = true;
            komunikat("Odkurzacz włączono");

        }
    }
    public void off(){
        if (stanOdkurzacza == true){
            stanOdkurzacza = false;
            komunikat("Odkurzacz wyłączono");
        }
    }
}
