package org.example;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pralka pralka = new Pralka();
        Odkurzacz odkurzacz = new Odkurzacz();
        Urzadzenie komunikat = new Urzadzenie();

        System.out.println("Podaj numer prania 1..12");
        int numerProgramu = scanner.nextInt();
        if (numerProgramu >= 1 && numerProgramu <= 12)
        {
        pralka.numerProgramuPrania(numerProgramu);
        System.out.println("Program został ustawiony");
        } else {
            System.out.println("Podano niepoprawny numer programu");
        }

        odkurzacz.on();
        odkurzacz.on();
        odkurzacz.on();
        komunikat.komunikat("Odkurtzacz wyładował się");
        odkurzacz.off();
    }
}
