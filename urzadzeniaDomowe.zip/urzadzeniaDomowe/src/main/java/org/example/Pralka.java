package org.example;

public class Pralka extends Urzadzenie{
    private int numerPrania = 0;
    public int numerProgramuPrania (int numerProgramu){
        if (numerProgramu >= 1 && numerProgramu <= 12){
            this.numerPrania = numerProgramu;
        } else {
            this.numerPrania = 0;
        }
        return  this.numerPrania;
    }
}
