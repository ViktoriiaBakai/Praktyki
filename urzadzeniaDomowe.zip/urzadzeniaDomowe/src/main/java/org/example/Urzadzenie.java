package org.example;

public class Urzadzenie {
//    ***************************************************
//    nazwa: komunikat
//    opis: metoda wyświetla komunikat (tekst) który jest wprowadzany w argumencie przy wyłowaniu metody
//    parametry: tresc, jest parametrem typu tekstowego. Wykorzystywany żeby wyświelic komunikat
//    zwracany typ i opis: brak
//    autor: bebebe
    public void komunikat (String tresc){
        System.out.println(tresc);
    }
}
