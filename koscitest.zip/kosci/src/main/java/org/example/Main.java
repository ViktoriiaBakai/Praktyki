package org.example;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static void main() {
        Scanner wpiszLiczbe = new Scanner(System.in);
        System.out.println("Podaj liczbę od 1 - 6: ");
        int liczba = wpiszLiczbe.nextInt();
        kosc object = new kosc(liczba);
        System.out.println("\n--- Pierwsza kostka ---");
        System.out.println("Liczba instancji: "+kosc.instancje);
        System.out.println("Liczba oczek: " + object.oczki + (" ") + object.wartoscKosci());
        System.out.println("Plik obrazu: " + object.obrazy[object.index]);


        kosc object2 = new kosc();
        System.out.println("\n--- Druga kostka ---");
        System.out.println("Liczba instacji: "+ kosc.instancje);
        System.out.println("Liczba oczek: " + object2.oczki + (" ") + object2.wartoscKosci());
        System.out.println("Nazwa pliku: " + object2.obrazy[object2.index]);


    }

}
