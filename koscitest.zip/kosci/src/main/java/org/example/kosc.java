package org.example;

import java.util.Random;

public class kosc {
    public static int instancje;
    public String[] obrazy = {"kosc0.png", "kosc1.png", "kosc2.png", "kosc3.png", "kosc4.png", "kosc5.png", "kosc6.png"};
    public int oczki;
    public int index;
    public boolean czyDostepna;
    Random random = new Random();

    public kosc(int wartoscKosci) {
        if (wartoscKosci <= 1 && wartoscKosci >= 6) {
            wartoscKosci = 0;
        }
        this.oczki = wartoscKosci;
        this.index = wartoscKosci;
        czyDostepna = true;
        instancje++;
    }

    public kosc() {
        int losowanie = random.nextInt(6) + 1;
        this.oczki = losowanie;
        this.index = losowanie;
        czyDostepna = true;
        instancje++;
    }

    public void rzutGdyDostepna() {
        int losowanie = random.nextInt(6) + 1;
        oczki = losowanie;
        index = losowanie;
    }

    public void blokujaca() {
        czyDostepna = false;
    }

    public String wartoscKosci() {
        switch (oczki) {
            case 1:
                return "jeden";
            case 2:
                return "dwa";
            case 3:
                return "trzy";
            case 4:
                return "cztery";
            case 5:
                return "pięć";
            case 6:
                return "sześć";
            default:
                return "brak";
        }
    }
}
