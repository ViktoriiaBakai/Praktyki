package org.example;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class koscTest {

    @Test
    void testWartosc(){
        for (int i = 0; i < 100; i++){
            int result = (int)(Math.random() * 6 ) + 1;
            assertTrue(result >= 1 && result <= 6);
        }
    }

        @Test
    void nieZmienia(){
        int dowartosc = 4;
        boolean isAvailable = false;
        int powatrosc = dowartosc;
        if (isAvailable){
            powatrosc = (int)(Math.random() * 6) + 1;
        }
        assertEquals(dowartosc, powatrosc);
        }
}